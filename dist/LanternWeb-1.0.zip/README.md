## LANTERNWEB

Hello hopefully this will be a bit more populated in the future but...

Welcome to LanternWeb!

A canvas based, 2D game engine you can run in any browser (i.e. in-built cross platform support).

- Getting Started:
    1. Copy and paste ALL of the files in the 'Getting Started Project' folder into a directory of your own
    2. Open that directory with your favourite text editor
    3. All game logic should use the in build entity component system and render using the layer system (See ExampleLayer.js)
    4. Dont forget when adding additional layers to add them to index.js so the engine can see them
    5. When ready to run the game, open index.html in your favourite browser and enjoy the game! 
    6. TIP! The developer console is EXTREMELY helpful for debugging LanternWeb games as you can destructure objs in the console itself. Check it out! 